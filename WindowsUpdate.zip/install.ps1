# Get the directory of the current script
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Run the first script with Execution Policy Bypass
powershell.exe -ExecutionPolicy Bypass -File "$scriptDir\copy_hide.ps1"

# Run the second script with Execution Policy Bypass
powershell.exe -ExecutionPolicy Bypass -File "$scriptDir\schedule.ps1"
