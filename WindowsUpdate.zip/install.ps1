<#
.SYNOPSIS
Displays a branded Windows update notification with snooze and reminder logic for end users.

.DESCRIPTION
This script shows a toast notification with an enterprise logo prompting users to install pending Windows updates. 
Users can snooze the notification up to 3 times, each for 3 hours. 
Once all snoozes are used, the script triggers persistent notifications every 3 minutes until the update is installed or acknowledged.
A log is generated under "C:\ProgramData\WindowsNotification\log.txt" caputing all the details for the notifications

.PARAMETER None
All logic and values are hardcoded for simplicity. Customize as needed.

.EXAMPLE
powershell.exe -executionpolicy bypass -file install.ps1

.NOTES
Author: SHIVAM KOUL
Version: 1.0
Date: 01/05/2025
#>

# Get the directory of the current script
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Run the first script with Execution Policy Bypass
powershell.exe -ExecutionPolicy Bypass -File "$scriptDir\copy_hide.ps1"

# Run the second script with Execution Policy Bypass
powershell.exe -ExecutionPolicy Bypass -File "$scriptDir\schedule.ps1"
