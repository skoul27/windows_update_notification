<#
.SYNOPSIS
Displays a branded Windows update notification with snooze and reminder logic for end users.

.DESCRIPTION
This script shows a toast notification with an enterprise logo prompting users to install pending Windows updates. 
Users can snooze the notification up to 3 times, each for 3 hours. 
Once all snoozes are used, the script triggers persistent notifications every 3 minutes until the update is installed or acknowledged.
A log is generated under "C:\ProgramData\WindowsNotification\log.txt" caputing all the details for the notifications

.PARAMETER None
All logic and values are hardcoded for simplicity. Customize as needed.

.EXAMPLE
powershell.exe -executionpolicy bypass -file install.ps1

.NOTES
Author: SHIVAM KOUL
Version: 1.0
Date: 01/05/2025
#>

# Get the directory of the current script
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Define source and destination paths
$sourcePath1 = "$scriptDir\logo.png" 
$sourcePath2 = "$scriptDir\WindowsUpdateRestart.ps1" 
$sourcePath3 = "$scriptDir\RunWindowsUpdateRestart.vbs" 

$destinationDir = "C:\ProgramData\WindowsNotification"
$destinationPath1 = "$destinationDir\logo.png"
$destinationPath2 = "$destinationDir\WindowsUpdateRestart.ps1"
$destinationPath3 = "$destinationDir\RunWindowsUpdateRestart.vbs"

# Check if the destination directory exists
if (-Not (Test-Path -Path $destinationDir)) {
    # Create the directory if it doesn't exist
    New-Item -Path $destinationDir -ItemType Directory
}

# Copy all the file
Copy-Item -Path $sourcePath1 -Destination $destinationPath1 -Force
Copy-Item -Path $sourcePath2 -Destination $destinationPath2 -Force
Copy-Item -Path $sourcePath3 -Destination $destinationPath3 -Force

