# Get the directory of the current script
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Define source and destination paths
$sourcePath1 = "$scriptDir\logo.png" 
$sourcePath2 = "$scriptDir\WindowsUpdateRestart.ps1" 
$sourcePath3 = "$scriptDir\RunWindowsUpdateRestart.vbs" 

$destinationDir = "C:\ProgramData\WindowsNotification"
$destinationPath1 = "$destinationDir\logo.png"
$destinationPath2 = "$destinationDir\WindowsUpdateRestart.ps1"
$destinationPath3 = "$destinationDir\RunWindowsUpdateRestart.vbs"

# Check if the destination directory exists
if (-Not (Test-Path -Path $destinationDir)) {
    # Create the directory if it doesn't exist
    New-Item -Path $destinationDir -ItemType Directory
}

# Copy all the file
Copy-Item -Path $sourcePath1 -Destination $destinationPath1 -Force
Copy-Item -Path $sourcePath2 -Destination $destinationPath2 -Force
Copy-Item -Path $sourcePath3 -Destination $destinationPath3 -Force

