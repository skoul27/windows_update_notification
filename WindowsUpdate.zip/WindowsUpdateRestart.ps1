<#
.SYNOPSIS
Displays a branded Windows update notification with snooze and reminder logic for end users.

.DESCRIPTION
This script shows a toast notification with an enterprise logo prompting users to install pending Windows updates. 
Users can snooze the notification up to 3 times, each for 3 hours. 
Once all snoozes are used, the script triggers persistent notifications every 3 minutes until the update is installed or acknowledged.
A log is generated under "C:\ProgramData\WindowsNotification\log.txt" caputing all the details for the notifications

.PARAMETER None
All logic and values are hardcoded for simplicity. Customize as needed.

.EXAMPLE
powershell.exe -executionpolicy bypass -file install.ps1

.NOTES
Author: SHIVAM KOUL
Version: 1.0
Date: 01/05/2025
#>


# Path to store the snooze counter, last snooze time, and deadline in the registry
$registryPath = "HKCU:\Software\MyUpdateNotification"
$snoozeCounterName = "SnoozeCounter"
$lastSnoozeName = "LastSnoozeTime"
$deadlineName = "CalculatedDeadline"
$deadlineCalculationDateName = "LastDeadlineCalculationDate"

# MDM deadline registry path
$deadlinePath = "HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Update"
$qualityUpdatesDeadlineValue = "ConfigureDeadlineForQualityUpdates"
$deferQualityUpdatePeriodValue = "DeferQualityUpdatesPeriodInDays"

# Path to the custom image you want to display in the notification
$customImage = "C:\ProgramData\WindowsNotification\logo.png"

# Path to log file for debugging
$logFilePath = "C:\ProgramData\WindowsNotification\log.txt"

function Log-Message($message) {
    Add-Content -Path $logFilePath -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - $message"
}

# Ensure that the BurntToast module is installed for all users
try {
    Import-Module -Name BurntToast -ErrorAction Stop
} catch {
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Install-Module -Name BurntToast -Force -SkipPublisherCheck
Import-Module -Name BurntToast
}

# Initialize the snooze counter and last snooze time if they don’t exist
function Initialize-SnoozeSettings {
    if (-not (Get-ItemProperty -Path $registryPath -Name $snoozeCounterName -ErrorAction SilentlyContinue)) {
        Set-ItemProperty -Path $registryPath -Name $snoozeCounterName -Value 0
    }
    if (-not (Get-ItemProperty -Path $registryPath -Name $lastSnoozeName -ErrorAction SilentlyContinue)) {
        Set-ItemProperty -Path $registryPath -Name $lastSnoozeName -Value (Get-Date).ToString('dd/MM/yyyy HH:mm:ss')
    }
}

Initialize-SnoozeSettings

# Read the current snooze counter and last snooze time
$snoozeCounter = Get-ItemPropertyValue -Path $registryPath -Name $snoozeCounterName
$lastSnoozeTimeRaw = Get-ItemPropertyValue -Path $registryPath -Name $lastSnoozeName

# Convert last snooze time to datetime
try {
    $lastSnoozeTime = [datetime]::ParseExact($lastSnoozeTimeRaw, 'dd/MM/yyyy HH:mm:ss', $null)
} catch {
    $lastSnoozeTime = Get-Date
    Log-Message "Failed to parse last snooze time. Using current time as fallback."
}

# Check if the deadline is already calculated and stored in the registry
$deadlineDate = Get-ItemPropertyValue -Path $registryPath -Name $deadlineName -ErrorAction SilentlyContinue
$lastDeadlineCalculationDate = Get-ItemPropertyValue -Path $registryPath -Name $deadlineCalculationDateName -ErrorAction SilentlyContinue

# Function to get the second Tuesday of the current month
function Get-SecondTuesday {
    $firstDayOfMonth = (Get-Date).AddDays(-1 * (Get-Date).Day + 1)  # First day of the current month
    $firstTuesday = $firstDayOfMonth.AddDays((2 - [int]$firstDayOfMonth.DayOfWeek + 7) % 7)  # First Tuesday
    return $firstTuesday.AddDays(7)  # Second Tuesday
}

# Function to calculate the deadline based on registry values
function Calculate-Deadline {
    $secondTuesday = Get-SecondTuesday
    Log-Message "Second Tuesday of the month: $secondTuesday"
    
    # Fetch the values for ConfigureDeadlineForQualityUpdates and DeferQualityUpdatePeriodInDays
    try {
        $qualityUpdatesDeadline = [int](Get-ItemProperty -Path $deadlinePath -Name $qualityUpdatesDeadlineValue -ErrorAction Stop).$qualityUpdatesDeadlineValue
        Log-Message "Quality Updates Deadline value from registry: $qualityUpdatesDeadline"
        
        # Read DeferQualityUpdatePeriodInDays
        $deferPeriodValue = Get-ItemPropertyValue -Path $deadlinePath -Name $deferQualityUpdatePeriodValue -ErrorAction SilentlyContinue
        if ($deferPeriodValue -eq $null) {
            Log-Message "DeferQualityUpdatePeriodInDays is null. Assuming 0 days."
            $deferPeriodValue = 0
        } else {
            $deferPeriodValue = [int]$deferPeriodValue
            Log-Message "DeferQualityUpdatePeriodInDays value from registry: $deferPeriodValue"
        }

        # Total days for the deadline calculation
        $totalDeadlineDays = $qualityUpdatesDeadline + $deferPeriodValue
        $deadlineDateCalculated = $secondTuesday.AddDays($totalDeadlineDays)

        Log-Message "Calculated Deadline Date: $deadlineDateCalculated"
        return $deadlineDateCalculated
    } catch {
        Log-Message "Failed to retrieve values from registry for deadline calculation."
        return $null
    }
}

# Check if a reboot is pending
function Is-RebootPending {
    $rebootRequiredKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"
    $rebootPending = Test-Path $rebootRequiredKey
    Log-Message "Reboot required key exists: $rebootPending"
    return $rebootPending
}

# Check if a reboot is pending and calculate the deadline if it is
if (Is-RebootPending) {
    if (-not $deadlineDate) {
        # Calculate and store the deadline only if it has not been calculated before
        $deadlineDate = Calculate-Deadline
        if ($deadlineDate) {
            # Store the calculated deadline in the registry for future use
            Set-ItemProperty -Path $registryPath -Name $deadlineName -Value $deadlineDate.ToString('dd/MM/yyyy HH:mm:ss')
            Set-ItemProperty -Path $registryPath -Name $deadlineCalculationDateName -Value (Get-Date).ToString('dd/MM/yyyy HH:mm:ss')
            Log-Message "Calculated deadline: $deadlineDate stored in registry."
        } else {
            Log-Message "Deadline calculation returned null. Notification will not be displayed."
        }
    } else {
        # Convert the stored deadline to datetime
        $deadlineDate = [datetime]::ParseExact($deadlineDate, 'dd/MM/yyyy HH:mm:ss', $null)
    }

    # Check if deadlineDate is still null before proceeding
    if ($deadlineDate -ne $null) {
        # Calculate the notification start date (1 day before the deadline)
        $startNotifyDate = $deadlineDate.AddDays(-1)
        Log-Message "Calculated notification start date: $startNotifyDate"

        # Function to show snooze notification with both buttons
        function Show-SnoozeNotification {
            $buttonRestartNow = New-BTButton -Content "Update Now" -Arguments "ms-settings:windowsupdate"
            $buttonSnooze = New-BTButton -Content "Snooze" -Arguments "snooze"

            New-BurntToastNotification -Text "Windows Update Requires Restart",  
            "Today is your last chance to restart before an automatic reboot tomorrow. Click 'Update Now' to restart, or snooze for 3 hours (up to 3 times)."  -Button $buttonRestartNow, $buttonSnooze -AppLogo $customImage -Sound 'Alarm9'
            Log-Message "Snooze notification displayed."
        }

        # Function to show persistent notification with "Update Now" button only
        function Show-PersistentNotification {
            $buttonRestartNow = New-BTButton -Content "Update Now" -Arguments "ms-settings:windowsupdate"

            New-BurntToastNotification -Text "Windows Update Requires Restart",  
            "Snooze limit reached. Please restart your device now to complete updates, or your device will restart automatically soon."  -Button $buttonRestartNow -AppLogo $customImage -Sound 'Alarm9'
            Log-Message "Persistent notification displayed."
        }

        # Function to show non-dismissible notification repeatedly
        function Show-NonDismissableNotification {
            while ($true) {
                Show-PersistentNotification
                Start-Sleep -Seconds 180
            }
        }

        # Check if a reboot is pending and within notification period
        if (Is-RebootPending) {
            if ((Get-Date) -ge $startNotifyDate) {
                $currentTimestamp = Get-Date
                $timeDifference = $currentTimestamp - $lastSnoozeTime

                # Check the snooze counter and if 3 hours have passed
                if ($snoozeCounter -lt 3 -and $timeDifference.TotalHours -ge 3) {
                    Show-SnoozeNotification

                    # Update snooze counter and last snooze time
                    $snoozeCounter++
                    Set-ItemProperty -Path $registryPath -Name $snoozeCounterName -Value $snoozeCounter
                    Set-ItemProperty -Path $registryPath -Name $lastSnoozeName -Value $currentTimestamp.ToString('dd/MM/yyyy HH:mm:ss')
                    Log-Message "Snooze counter updated to $snoozeCounter."
                } elseif ($snoozeCounter -ge 3) {
                    Show-NonDismissableNotification
                } else {
                    Log-Message "Notification already snoozed. Waiting for 3 hours to pass."
                }
            } else {
                Log-Message "Not within the notification period. Current date: $(Get-Date), Notification Start Date: $startNotifyDate."
            }
        }
    } else {
        Log-Message "Deadline is null. Skipping notification display."
    }
} else {
    # No reboot pending, reset snooze counter
    Set-ItemProperty -Path $registryPath -Name $snoozeCounterName -Value 0
    Set-ItemProperty -Path $registryPath -Name $lastSnoozeName -Value (Get-Date).ToString('dd/MM/yyyy HH:mm:ss')
    Log-Message "No reboot is pending. Snooze counter reset."

    # Clear deadline-related values for the next month
    Remove-ItemProperty -Path $registryPath -Name $deadlineName -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $registryPath -Name $deadlineCalculationDateName -ErrorAction SilentlyContinue
    Log-Message "Deadline values cleared for the next month."
}