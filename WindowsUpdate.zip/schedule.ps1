<#
.SYNOPSIS
Displays a branded Windows update notification with snooze and reminder logic for end users.

.DESCRIPTION
This script shows a toast notification with an enterprise logo prompting users to install pending Windows updates. 
Users can snooze the notification up to 3 times, each for 3 hours. 
Once all snoozes are used, the script triggers persistent notifications every 3 minutes until the update is installed or acknowledged.
A log is generated under "C:\ProgramData\WindowsNotification\log.txt" caputing all the details for the notifications

.PARAMETER None
All logic and values are hardcoded for simplicity. Customize as needed.

.EXAMPLE
powershell.exe -executionpolicy bypass -file install.ps1

.NOTES
Author: SHIVAM KOUL
Version: 1.0
Date: 01/05/2025
#>

# Define the task name and the path to the VBS wrapper script
$taskName = "MonitorWindowsUpdateRestart"
$vbsPath = "C:\ProgramData\WindowsNotification\RunWindowsUpdateRestart.vbs"  # Ensure this is the correct path to your VBS script

# Create a new scheduled task action to run the VBS script
$action = New-ScheduledTaskAction -Execute "wscript.exe" -Argument "`"$vbsPath`""

# Create a trigger to run at logon for each user
$triggerAtLogon = New-ScheduledTaskTrigger -AtLogon

# Create a trigger to run at startup for each user
$triggerAtStart = New-ScheduledTaskTrigger -AtStartup

# Create a trigger to run every 30 minutes with a very large repetition duration (e.g., 10 years)
$triggerEvery20Mins = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 20) -RepetitionDuration (New-TimeSpan -Days 3650)  # 10 years

# Define the task principal to run for all users
$principal = New-ScheduledTaskPrincipal -GroupId "Users" -RunLevel Highest

# Set task settings to run even on battery
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task with both triggers and the power settings for all users
Register-ScheduledTask -Action $action -Trigger $triggerAtLogon, $triggerEvery20Mins, $triggerAtStart -TaskName $taskName -Principal $principal -Settings $settings -Force

# Start the scheduled task immediately after it is created
Start-ScheduledTask -TaskName $taskName
